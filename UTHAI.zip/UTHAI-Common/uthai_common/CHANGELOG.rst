^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package uthai_common
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2018-03-11)
-----------
* add tutorial to run uthai gazebo simulation
* Contributors: Liews

0.0.1 (2018-02-24)
-----------
* first initialize meta package