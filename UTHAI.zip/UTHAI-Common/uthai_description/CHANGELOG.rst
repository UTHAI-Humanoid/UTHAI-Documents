^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package uthai_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.4 (2018-03-11)
-----------
* redefine inertia
* update stl file
* add new dynamic properties
* Contributors: Liews

0.0.3 (2018-03-03)
-----------
* split xacro file for easy to modify
* Contributors: Liews

0.0.2 (2018-03-02)
-----------
* add doc UTHAI dynamic properties
* add meshes file
* display.launch
* uthai.xacro
* Contributors: Liews

0.0.1 (2018-02-24)
-----------
* first initialize
* Contributors: Liews