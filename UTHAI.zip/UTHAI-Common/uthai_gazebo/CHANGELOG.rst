^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package uthai_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.3 (2018-03-11)
-----------
* add test script for uthai robot
* Contributors: Liews

0.0.2 (2018-03-03)
-----------
* gazebo add uthai robot
* No physic engine
* Contributors: Liews

0.0.1 (2018-02-24)
-----------
* first initialize
* Contributors: Liews