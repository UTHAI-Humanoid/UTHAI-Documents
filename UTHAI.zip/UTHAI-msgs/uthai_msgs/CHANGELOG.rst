^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package uthai_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2018-02-24)
-----------
* first initialize meta package