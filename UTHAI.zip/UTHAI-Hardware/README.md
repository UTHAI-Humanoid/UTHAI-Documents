# UTHAI-Hardware
UTHAI Humanoid is an open-source humanoid robot. For research and education purposes.
