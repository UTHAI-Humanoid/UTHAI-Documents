### 1. Overview

ในส่วนนี้จะเป็นการติดตั้ง ROS\(Robot Operating System\) สำหรับ UTHAI

### 2. How to install ROS

* OPC : [[ROS install on Operating PC|ROS Installation OPC]]
* MPPC : [[ROS install on Motion and Perception PC|ROS Installation MPPC]]


<br>[[&lt;&lt; Back|Home]]