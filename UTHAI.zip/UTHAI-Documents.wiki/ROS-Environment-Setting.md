### 1. Overview  
This page introduces how to configure the ROS for THORMANG3.  
  
### 2. SetUp  
#### 2.1 ROS Environment Setting  
> Reference : [http://wiki.ros.org/ROS/Tutorials/InstallingandConfiguringROSEnvironment](http://wiki.ros.org/ROS/Tutorials/InstallingandConfiguringROSEnvironment)  
  
#### 2.2 ROS Network Setup  
> Reference : [ROS Network Setup](http://wiki.ros.org/ROS/NetworkSetup)  
  
### 3. Example Setting  
Above configuration has to be repeatedly done whenever a new terminal window is created. 
The following method will load configuration file when creating a terminal window. 
ROS Network setup is also performed when the configuration file is loaded.
  
  ![](https://github.com/ROBOTIS-GIT/ROBOTIS-Documents/blob/master/wiki-images/ROBOTIS-THORMANG3/THORMANG3_network_map.png) 

#### 3.1 System configuration  
1. PPC(Perception PC)
  - core
  - IP : 10.17.3.35
2. MPC(Motion PC)
  - IP : 10.17.3.30
3. OPC(Operation PC)
  - IP : 10.17.3.100

#### 3.2 Example setting for PPC
  1. Open the bash file with an editor to apply configuration.   
     ```
     $ gedit ~/.bashrc
     ```
    
  2. Append below contents at the end of the `.bashrc` file. 
     ```bash
     # Set ROS Kinetic
     source /opt/ros/kinetic/setup.bash
     source ~/catkin_ws/devel/setup.bash
 	
     ##### Set ROS Network ####
     # PPC CORE(10.17.3.35)
     export ROS_MASTER_URI=http://10.17.3.35:11311
 	
     # local ROS IP
     export ROS_IP=10.17.3.35
     ```

  3. Use below command to apply modified configuration or open a new terminal window. 
     ```
     $ source ~/.bashrc
     ```

#### 3.3 Example setting for MPC
  1. Open the bash file with an editor to apply configuration. 
     ```
     $ gedit ~/.bashrc
     ```
    
  2. Append below contents at the end of the `.bashrc` file. 
     ```bash
     # Set ROS Kinetic
     source /opt/ros/kinetic/setup.bash
     source ~/catkin_ws/devel/setup.bash
 	
     ##### Set ROS Network ####
     # PPC CORE(10.17.3.35)
     export ROS_MASTER_URI=http://10.17.3.35:11311
 	
     # local ROS IP
     export ROS_IP=10.17.3.30
     ```

  3. Use below command to apply modified configuration or open a new terminal window. 
      ```
      $ source ~/.bashrc
      ```

#### 3.4 Example setting for OPC
  1. Open the bash file with an editor to apply configuration. 
      ```
      $ gedit ~/.bashrc
      ```
    
  2. Append below contents at the end of the `.bashrc` file. 
     ```bash
     # Set ROS Kinetic
     source /opt/ros/kinetic/setup.bash
     source ~/catkin_ws/devel/setup.bash
 	
     ##### Set ROS Network ####
     # PPC CORE(10.17.3.35)
     export ROS_MASTER_URI=http://10.17.3.35:11311
 	
     # local ROS IP
     export ROS_IP=10.17.3.100
     ```

  3. Use below command to apply modified configuration or open a new terminal window. 
     ```
     $ source ~/.bashrc
     ```

### 4. Time Synchronization
In order to run the ROS on multiple PCs, each PC clock has to be synchronized. 
The following script file comes in handy for this synchronization procedure. 
PPC time becomes the reference for synchronization, and perform below procedures only for MPC and OPC. 

 1. Create the script file with an editor. 
   ```
   $ gedit ~/timesync
   ```
 2. Copy and paste below contents to the script file 
     ```bash
     #! /bin/sh
    sudo date --set='-2 secs'
    sudo ntpdate 10.17.3.35
    sudo hwclock -w
    ```
      > PPC(10.17.3.35)  
  
 3. Modify the script file permission(Add execute permission)  
   ```
   $ sudo chmod +x timesync
   ```
 4. Run the script file to sync time for PPC, MPC and OPC.
    ```
    $ ~/timesync
    ```
  
 - When NTP socket is running 
  Stop the ntp service and sync time.  

    ```
    $ sudo service ntp stop
    $ ~/timesync  
    ```  
  

<br>[[&lt;&lt; Back|THORMANG3 User's Guide]]