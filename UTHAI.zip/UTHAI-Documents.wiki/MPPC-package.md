 ### 1. [[UTHAI Modules]]
 - #### Motion Module
   1. [[op3_action_module]] : This module manages every joint actions.  
   2. [[op3_base_module]] : This module manages initial pose and basic functions.  
   3. [[op3_head_control_module]] : This module controls the head.  
   4. [[op3_walking_module]] : This module controls walking.  
   5. [[op3_online_walking_module]] : This module controls online-walking(upgraded walking).
   
   1. [[thormang3_manager]] : THORMANG3 Manager
   2. [[thormang3_kinematics_dynamics]] : THORMANG3 kinematics & dynamics library
   3. [[thormang3_action_module]] : Modules for Action
   4. [[thormang3_base_module]] : Basic Modules for initial posture
   5. [[thormang3_manipulation_module]] : Modules for Manipulation
   6. [[thormang3_walking_module]] : Modules for Walking
   7. [[thormang3_head_control_module]] : Modules for Head control
   8. [[ati_ft_sensor]] : Libraries for ATI ft sensor
   9. [[thormang3_feet_ft_module]] : Modules for FT sensors in the foot
   10. [[thormang3_balance_control]] : Library for Balance Algorithm
   11. [[imu-3dm-gx4]] : Node for the IMU sensor
 
 - #### Sensor Module
   1. [[open_cr_module]] : This module is required to use OpenCR as a sensor.  
   
   1. [[thormang3_sensors]] : Sensor related programs and the Launch file
   2. [[thormang3_simple_demo]] : Simple demos for THORMANG3
 
### 2. [[op3_manager]]
  The package that controls OP3 using framework and various modules.   
    
### 3. Others
  1. [[op3_balance_control]]
  2. [[op3_localization]]  
  3. [[op3_optimization]]
  
 
<br>[[&lt;&lt; Back|Home]]
