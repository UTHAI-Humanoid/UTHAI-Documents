### 1. Overview  
UTHAI Gazebo Simulation

### 2. Gazebo with ROS  
[Connect to ROS](http://gazebosim.org/tutorials?cat=connect_ros)

### 3. Package  
`config` : ros controller for gazebo   
`launch` : launch files to execute gazebo simulation   
`worlds` : simulation environments   
  
<br>[[&lt;&lt; Back|Common package]]