### 1. Overview  

* MPPC : Ubuntu Mate
* OPC : Ubuntu 16.04 LTS

### 2. How to install Ubuntu  
> Reference : [Install Ubuntu](http://www.ubuntu.com/download/desktop/install-ubuntu-desktop)


<br>[[&lt;&lt; Back|Home]]