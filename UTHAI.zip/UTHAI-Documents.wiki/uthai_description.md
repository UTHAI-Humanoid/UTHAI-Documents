### 1. Overview  
UTHAI URDF Model
<img src="https://github.com/UTHAI-Humanoid/UTHAI-Documents/blob/master/wiki-images/uthai_urdf_rviz.png?raw=true"/>


### 2. Make a URDF Model  
[URDF-ROS Wiki](http://wiki.ros.org/urdf)

### 3. Package  
`doc` : document for UTHAI joint & link information   
`launch` : launch file to execute Rviz   
`meshes` : STL files of UTHAI's each parts   
`urdf` : urdf & xacro files for UTHAI model

<br>[[&lt;&lt; Back|Common package]]