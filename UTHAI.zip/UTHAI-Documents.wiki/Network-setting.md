### 1. Overview

การตั้งค่า network MPPC\(Motion and Perception PC\) สำหรับหุ่นยนต์ และ OPC\(Operting PC\) คอมพิวเตอร์ภายนอกให้เชื่อมต่อกันได้

### 2. Network setting

@to-edit

![](https://github.com/UTHAI-Humanoid/UTHAI-Documents/blob/master/wiki-images/UTHAI_network_map.png?raw=true)

#### 2.1 AP Setting

* AP Common Information
* Model : D-Link
* Account
* Username : admin
* Password : admin

AP Server

* IP Address : 10.XX.XX.XX
* WiFi Name \(2.4G\) : UTHAI-S24
* WiFi Name \(5G\) : UTHAI-S05
* WiFi Password : maibork rok

#### 2.2 PC Setting

* MPPC \(Motion and Perception PC\)
* IP Address : 10.XX.XX.XX
* Netmask : 255.255.255.0
* Gateway : 10.XX.XX.1

* OPC \(Operating PC\)
* IP Address : 10.XX.XX.XX
* Netmask : 255.255.255.0
* Gateway : 10.XX.XX.1
 

<br>[[&lt;&lt; Back|Home]]